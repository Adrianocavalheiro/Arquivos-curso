package com.entra21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEntra21Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiEntra21Application.class, args);
	}

}
