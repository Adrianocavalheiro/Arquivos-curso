package com.entra21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiEntra21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
